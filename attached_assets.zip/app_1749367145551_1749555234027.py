import os
import logging
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from video_downloader import VideoDownloader

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
CORS(app)

downloader = VideoDownloader()

@app.route('/')
def index():
    """Main page with YouTube downloader interface"""
    return render_template('index.html')

@app.route('/get_video_info', methods=['POST'])
def get_video_info():
    """Get video information and available formats"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({'error': 'Please provide a valid YouTube URL'}), 400
        
        # Validate YouTube URL
        if not downloader.is_valid_youtube_url(url):
            return jsonify({'error': 'Please provide a valid YouTube URL'}), 400
        
        # Get video information
        video_info = downloader.get_video_info(url)
        
        if not video_info:
            return jsonify({'error': 'Unable to fetch video information. Please check the URL.'}), 400
        
        return jsonify({
            'success': True,
            'video_info': video_info
        })
        
    except Exception as e:
        logging.error(f"Error getting video info: {str(e)}")
        return jsonify({'error': 'An error occurred while fetching video information'}), 500

@app.route('/download', methods=['POST'])
def download_video():
    """Direct download without storing files"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        format_id = data.get('format_id', '')
        download_type = data.get('download_type', 'video')
        
        if not url or not format_id:
            return jsonify({'error': 'Missing required parameters'}), 400
        
        # Validate YouTube URL
        if not downloader.is_valid_youtube_url(url):
            return jsonify({'error': 'Please provide a valid YouTube URL'}), 400
        
        # Get video info to determine filename
        video_info = downloader.get_video_info(url)
        if not video_info:
            return jsonify({'error': 'Unable to fetch video information'}), 400
        
        # Generate direct download URL
        download_url = downloader.get_direct_download_url(url, format_id, download_type)
        
        if download_url['success']:
            return jsonify({
                'success': True,
                'download_url': download_url['url'],
                'filename': download_url['filename'],
                'direct': True
            })
        else:
            return jsonify({'error': download_url['error']}), 400
        
    except Exception as e:
        logging.error(f"Error starting download: {str(e)}")
        return jsonify({'error': 'An error occurred while starting the download'}), 500

# Direct download implementation - no server-side file storage needed

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
